#!/bin/bash
THRESHOLD=80
USAGE=$(df / | tail -1 | awk '{print $5}' | sed 's/%//')
if [ "$USAGE" -ge "$THRESHOLD" ]; then
    echo "Warning: Disk usage is at $USAGE%" | mail -s "Disk Usage Alert" root@localhost
fi
