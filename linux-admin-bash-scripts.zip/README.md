# Linux Admin Bash Scripts

This repository contains useful Bash scripts for automating Linux system administration tasks.

## Scripts
- **disk_monitor.sh** - Monitors disk usage and alerts if usage exceeds a threshold.
- **user_management.sh** - Adds or deletes users from the system.
- **log_rotation.sh** - Rotates logs when they exceed a certain size.
- **backup.sh** - Creates compressed backups of important files.

## Usage
Make the scripts executable and run them:
```bash
chmod +x script.sh
./script.sh
```
