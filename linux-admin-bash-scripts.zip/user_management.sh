#!/bin/bash
echo "User Management Script"
echo "1. Add User"
echo "2. Delete User"
read -p "Choose an option: " OPTION
if [ "$OPTION" == "1" ]; then
    read -p "Enter username: " USERNAME
    sudo adduser $USERNAME
elif [ "$OPTION" == "2" ]; then
    read -p "Enter username: " USERNAME
    sudo deluser $USERNAME
else
    echo "Invalid option"
fi
