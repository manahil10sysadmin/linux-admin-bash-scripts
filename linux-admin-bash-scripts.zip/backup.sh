#!/bin/bash
SOURCE="/home/user/data"
DEST="/backup"
DATE=$(date +%F)
tar -czf "$DEST/backup-$DATE.tar.gz" "$SOURCE"
echo "Backup completed at $DEST/backup-$DATE.tar.gz"
