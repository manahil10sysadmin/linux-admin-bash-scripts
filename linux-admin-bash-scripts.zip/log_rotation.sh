#!/bin/bash
LOG_DIR="/var/log/myapp"
LOG_FILE="app.log"
MAX_SIZE=10485760  # 10MB

if [ -f "$LOG_DIR/$LOG_FILE" ]; then
    SIZE=$(stat -c%s "$LOG_DIR/$LOG_FILE")
    if [ "$SIZE" -ge "$MAX_SIZE" ]; then
        mv "$LOG_DIR/$LOG_FILE" "$LOG_DIR/app-$(date +%F).log"
        gzip "$LOG_DIR/app-$(date +%F).log"
        touch "$LOG_DIR/$LOG_FILE"
    fi
fi
